import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize Gemini client on the server side
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

// API endpoint to analyze a decision
app.post("/api/decision/analyze", async (req, res) => {
  try {
    const { title, context, options, criteria } = req.body;

    if (!title) {
      return res.status(400).json({ error: "Decision title is required." });
    }

    const optionsList = options && options.length > 0 ? options : ["Yes", "No"];
    const criteriaText = criteria && criteria.length > 0 
      ? `Criteria of interest to evaluate: ${criteria.join(", ")}` 
      : "Identify the most critical decision factors automatically (e.g. Cost, Ease, Time, Risk, Long-term Value).";

    const prompt = `
      You are a warm, wise, objective, deeply analytical, and supportive decision-making guide.
      Analyze the following decision scenario with care and produce an exhaustive, structured "Tiebreaker Report" containing pros and cons, a comparison table, a SWOT analysis, a weighted decision matrix, and a final verdict. Be clear, balanced, empathetic, and constructive in your reasoning and advice.
      
      CRITICAL OUTCOME GUIDELINE: Provide highly in-depth, rich, and insightful responses. Do not make the output concise. Each description, explanation, reasoning, and SWOT item should be thorough, detailed, and highly contextualized to the user's specific scenario.

      Decision Topic: ${title}
      Context: ${context || "None provided."}
      Options to compare: ${optionsList.join(", ")}
      ${criteriaText}

      Instructions for values and scores:
      - Weighted Decision Matrix: Create 4-5 relevant criteria (factors). Assign each a weight between 0.1 and 0.4 such that the SUM of all factor weights equals exactly 1.0.
      - Scores: Assign integer scores from 1 to 10 where higher is always better (e.g., higher score means lower cost, lower risk, better convenience, etc.).
      - Pros & Cons scores: Assign gravity/impact scores from 1 (minor) to 5 (critical impact).

      You MUST return a JSON object matching this schema precisely:
      - title: The decision title (string)
      - summary: High-level comprehensive overview of the decision scenario, trade-offs, and emotional or logistical stakes involved (string)
      - options: The list of compared options (array of strings)
      - prosCons: For each option, list pros and cons:
        - option: Option name (string)
        - pros: Array of { text: string, score: number (1 to 5), description: string } (Make descriptions highly detailed and detailed enough to explain the context)
        - cons: Array of { text: string, score: number (1 to 5), description: string } (Make descriptions highly detailed and detailed enough to explain the context)
      - comparisonTable: A structural comparison:
        - headers: Column names including "Criteria" and the option names (array of strings)
        - rows: Array of { criteria: string, scores: Array of { option: string, score: number }, explanation: string } (Provide rich, comprehensive, side-by-side comparison notes for each criterion)
      - swotAnalysis: SWOT analysis for each option:
        - option: Option name (string)
        - strengths: Array of strings (highly detailed, informative items)
        - weaknesses: Array of strings (highly detailed, informative items)
        - opportunities: Array of strings (highly detailed, informative items)
        - threats: Array of strings (highly detailed, informative items)
      - decisionMatrix: A weighted factor scoring:
        - factors: Array of { name: string, weight: number (float), scores: Array of { option: string, score: number } }
      - verdict: The ultimate tiebreaker resolution:
        - winner: The recommended option (string)
        - confidenceScore: Percentage confidence (number from 0 to 100)
        - tiebreakerReasoning: A deeply analytical, thorough, warm, and highly insightful explanation of why this option is superior, resolving key trade-offs and providing the user with deep clarity (string)
        - nextSteps: 3-4 actionable, concrete, and comprehensive next steps for the decision-maker (array of strings)
    `;

    // Define response schema for type safety and structure enforcement
    const responseSchema = {
      type: Type.OBJECT,
      properties: {
        title: { type: Type.STRING },
        summary: { type: Type.STRING },
        options: {
          type: Type.ARRAY,
          items: { type: Type.STRING }
        },
        prosCons: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              option: { type: Type.STRING },
              pros: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    text: { type: Type.STRING },
                    score: { type: Type.INTEGER },
                    description: { type: Type.STRING }
                  },
                  required: ["text", "score", "description"]
                }
              },
              cons: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    text: { type: Type.STRING },
                    score: { type: Type.INTEGER },
                    description: { type: Type.STRING }
                  },
                  required: ["text", "score", "description"]
                }
              }
            },
            required: ["option", "pros", "cons"]
          }
        },
        comparisonTable: {
          type: Type.OBJECT,
          properties: {
            headers: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            rows: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  criteria: { type: Type.STRING },
                  scores: {
                    type: Type.ARRAY,
                    items: {
                      type: Type.OBJECT,
                      properties: {
                        option: { type: Type.STRING },
                        score: { type: Type.INTEGER }
                      },
                      required: ["option", "score"]
                    }
                  },
                  explanation: { type: Type.STRING }
                },
                required: ["criteria", "scores", "explanation"]
              }
            }
          },
          required: ["headers", "rows"]
        },
        swotAnalysis: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              option: { type: Type.STRING },
              strengths: { type: Type.ARRAY, items: { type: Type.STRING } },
              weaknesses: { type: Type.ARRAY, items: { type: Type.STRING } },
              opportunities: { type: Type.ARRAY, items: { type: Type.STRING } },
              threats: { type: Type.ARRAY, items: { type: Type.STRING } }
            },
            required: ["option", "strengths", "weaknesses", "opportunities", "threats"]
          }
        },
        decisionMatrix: {
          type: Type.OBJECT,
          properties: {
            factors: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  name: { type: Type.STRING },
                  weight: { type: Type.NUMBER },
                  scores: {
                    type: Type.ARRAY,
                    items: {
                      type: Type.OBJECT,
                      properties: {
                        option: { type: Type.STRING },
                        score: { type: Type.INTEGER }
                      },
                      required: ["option", "score"]
                    }
                  }
                },
                required: ["name", "weight", "scores"]
              }
            }
          },
          required: ["factors"]
        },
        verdict: {
          type: Type.OBJECT,
          properties: {
            winner: { type: Type.STRING },
            confidenceScore: { type: Type.INTEGER },
            tiebreakerReasoning: { type: Type.STRING },
            nextSteps: { type: Type.ARRAY, items: { type: Type.STRING } }
          },
          required: ["winner", "confidenceScore", "tiebreakerReasoning", "nextSteps"]
        }
      },
      required: ["title", "summary", "options", "prosCons", "comparisonTable", "swotAnalysis", "decisionMatrix", "verdict"]
    };

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        systemInstruction: "You are a warm, wise, deeply analytical, and highly supportive decision-making advisor. Provide thorough, comprehensive, and insightful structured analyses to help users navigate complex choices. Ensure explanations, SWOT items, pros/cons descriptions, and reasoning are comprehensive, deeply reasoned, and rich in practical guidance.",
        responseMimeType: "application/json",
        responseSchema: responseSchema,
        temperature: 0.1, // Highly objective and consistent outputs
      }
    });

    const reportText = response.text;
    if (!reportText) {
      throw new Error("No response received from the decision model.");
    }

    const report = JSON.parse(reportText);
    res.json(report);
  } catch (error: any) {
    console.error("Error analyzing decision:", error);
    res.status(500).json({ error: error.message || "An error occurred while generating the tiebreaker report." });
  }
});

// Setup Vite or Static File serving
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
