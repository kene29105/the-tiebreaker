import React, { useState, useEffect } from "react";
import { 
  HelpCircle, 
  Trash2, 
  CheckCircle, 
  AlertTriangle, 
  TrendingUp, 
  BarChart3, 
  Layers, 
  History, 
  RefreshCw, 
  Bookmark,
  Calendar,
  Award,
  Zap,
  Check
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import DecisionForm from "./components/DecisionForm";
import { DecisionReport, DecisionRecord } from "./types";

export default function App() {
  const [history, setHistory] = useState<DecisionRecord[]>([]);
  const [currentRecord, setCurrentRecord] = useState<DecisionRecord | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<"verdict" | "matrix" | "comparison" | "swot" | "proscons">("verdict");

  // Load history on mount
  useEffect(() => {
    const saved = localStorage.getItem("tiebreaker_history");
    if (saved) {
      try {
        const parsed = JSON.parse(saved) as DecisionRecord[];
        setHistory(parsed);
        if (parsed.length > 0) {
          setCurrentRecord(parsed[0]);
        }
      } catch (e) {
        console.error("Failed to parse history", e);
      }
    }
  }, []);

  // Save history helper
  const saveHistory = (newHistory: DecisionRecord[]) => {
    setHistory(newHistory);
    localStorage.setItem("tiebreaker_history", JSON.stringify(newHistory));
  };

  const handleAnalyze = async (title: string, context: string, options: string[], criteria: string[]) => {
    setIsLoading(true);
    setError(null);

    const tempRecord: DecisionRecord = {
      id: crypto.randomUUID(),
      title,
      context,
      options,
      criteria,
      createdAt: new Date().toISOString(),
    };

    try {
      const response = await fetch("/api/decision/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title, context, options, criteria }),
      });

      if (!response.ok) {
        const errJson = await response.json().catch(() => ({}));
        throw new Error(errJson.error || "Failed to generate decision report from AI.");
      }

      const report: DecisionReport = await response.json();
      const completedRecord = { ...tempRecord, report };

      const updatedHistory = [completedRecord, ...history.filter(h => h.title !== title)];
      saveHistory(updatedHistory);
      setCurrentRecord(completedRecord);
      setActiveTab("verdict");
    } catch (err: any) {
      console.error(err);
      setError(err.message || "An unexpected error occurred during analysis.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleSelectRecord = (record: DecisionRecord) => {
    setCurrentRecord(record);
    setError(null);
  };

  const handleDeleteRecord = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = history.filter(h => h.id !== id);
    saveHistory(updated);
    if (currentRecord?.id === id) {
      setCurrentRecord(updated.length > 0 ? updated[0] : null);
    }
  };

  const handleClearHistory = () => {
    if (window.confirm("Are you sure you want to clear your decision history?")) {
      saveHistory([]);
      setCurrentRecord(null);
    }
  };

  const handleNewDecision = () => {
    setCurrentRecord(null);
    setError(null);
  };

  // Compute calculated matrix options and scores with robust normalization
  const getMatrixScores = (report: DecisionReport) => {
    const scoresMap: { [key: string]: number } = {};
    if (!report?.options || !report?.decisionMatrix?.factors) return [];

    report.options.forEach(opt => {
      if (opt) {
        scoresMap[opt.toLowerCase().trim()] = 0;
      }
    });

    report.decisionMatrix.factors.forEach(factor => {
      if (factor?.scores) {
        factor.scores.forEach(s => {
          if (s?.option) {
            const optionKey = s.option.toLowerCase().trim();
            if (scoresMap[optionKey] !== undefined) {
              scoresMap[optionKey] += (s.score || 0) * (factor.weight || 0);
            }
          }
        });
      }
    });

    return report.options
      .map((opt) => {
        const optionKey = opt.toLowerCase().trim();
        const totalScore = scoresMap[optionKey] || 0;
        return { option: opt, totalScore: Math.round(totalScore * 10) / 10 };
      })
      .sort((a, b) => b.totalScore - a.totalScore);
  };

  const matrixResults = currentRecord?.report ? getMatrixScores(currentRecord.report) : [];

  return (
    <div id="tiebreaker-app-root" className="min-h-screen flex flex-col relative bg-[#f6f5f2] text-stone-850">
      
      {/* Header */}
      <header id="app-header" className="sticky top-0 z-40 border-b border-stone-200/60 bg-white/85 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3 cursor-pointer group" onClick={handleNewDecision}>
            <div className="w-9 h-9 rounded-xl bg-stone-900 flex items-center justify-center text-white font-serif font-black text-lg group-hover:bg-amber-600 transition-all duration-250 shadow-xs">
              T
            </div>
            <div>
              <h1 className="text-sm font-bold tracking-tight text-stone-900 font-display flex items-center gap-1.5">
                The Tiebreaker
              </h1>
              <p className="text-[10px] text-stone-400 font-mono tracking-wider uppercase">
                A Friendly Decision Guide
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {history.length > 0 && (
              <button
                id="header-new-decision-btn"
                onClick={handleNewDecision}
                className="flex items-center gap-1 px-3 py-1.5 bg-white hover:bg-stone-50 text-stone-700 border border-stone-200 rounded-lg text-xs font-semibold tracking-wide transition duration-150 cursor-pointer shadow-xs"
              >
                New Choice
              </button>
            )}
            <div className="hidden sm:flex items-center gap-1.5 bg-stone-100 border border-stone-200 px-2.5 py-1 rounded-lg text-[10px] font-mono text-stone-500">
              <span className="w-1.5 h-1.5 rounded-full bg-amber-600 animate-pulse"></span>
              Advisor Ready
            </div>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main id="app-main" className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 grid grid-cols-1 lg:grid-cols-12 gap-8 relative z-10">
        
        {/* Sidebar - Recent Choices History */}
        <aside id="app-sidebar" className="lg:col-span-3 order-2 lg:order-1 flex flex-col gap-5">
          <div className="bg-white border border-stone-200 rounded-2xl p-5 shadow-xs flex-1 flex flex-col min-h-[350px]">
            <div className="flex items-center justify-between mb-4 pb-3 border-b border-stone-100">
              <h3 className="text-[10px] font-mono uppercase tracking-widest text-stone-500 flex items-center gap-1.5 font-bold">
                <History className="w-3.5 h-3.5 text-stone-400" /> Recent Choices ({history.length})
              </h3>
              {history.length > 0 && (
                <button
                  id="clear-all-history"
                  onClick={handleClearHistory}
                  className="text-stone-400 hover:text-red-600 text-xs transition p-1 cursor-pointer"
                  title="Clear decision history"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              )}
            </div>

            {history.length === 0 ? (
              <div className="flex-1 flex flex-col items-center justify-center text-center p-6 space-y-2">
                <Bookmark className="w-8 h-8 text-stone-300 stroke-1" />
                <p className="text-xs font-semibold text-stone-400">History is empty</p>
                <p className="text-[10px] text-stone-400 max-w-[150px]">Once you evaluate some options, they'll appear here for easy comparison.</p>
              </div>
            ) : (
              <div className="space-y-2.5 overflow-y-auto max-h-[500px] flex-1 pr-1">
                {history.map((record) => {
                  const isSelected = currentRecord?.id === record.id;
                  const winner = record.report?.verdict.winner;
                  return (
                    <div
                      key={record.id}
                      id={`history-item-${record.id}`}
                      onClick={() => handleSelectRecord(record)}
                      className={`group relative text-left p-3.5 rounded-xl border transition-all duration-150 cursor-pointer select-none flex flex-col gap-2 ${
                        isSelected
                          ? "bg-stone-50 border-stone-400/80 shadow-xs ring-1 ring-stone-400/10"
                          : "bg-white hover:bg-stone-50/50 border-stone-200 text-stone-700"
                      }`}
                    >
                      <span className={`font-semibold text-xs font-display line-clamp-2 leading-relaxed transition-colors ${
                        isSelected ? "text-stone-950" : "text-stone-700 group-hover:text-stone-950"
                      }`}>
                        {record.title}
                      </span>
                      
                      <div className="flex items-center justify-between text-[9px] mt-1 font-mono">
                        <span className="text-stone-400 flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          {new Date(record.createdAt).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}
                        </span>
                        {winner && (
                          <span className={`px-1.5 py-0.5 rounded-md font-bold ${
                            isSelected ? "bg-amber-100 text-amber-900 border border-amber-200" : "bg-stone-100 text-stone-500"
                          }`}>
                            Winner: {winner.substring(0, 12)}{winner.length > 12 ? "..." : ""}
                          </span>
                        )}
                      </div>

                      <button
                        id={`delete-record-${record.id}`}
                        onClick={(e) => handleDeleteRecord(record.id, e)}
                        className="absolute top-2.5 right-2.5 p-1 rounded-md opacity-0 group-hover:opacity-100 hover:bg-red-50 hover:text-red-600 transition duration-150 text-stone-400 cursor-pointer"
                        title="Delete choice"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Core Philosophy Card */}
          <div className="bg-white border border-stone-200 rounded-2xl p-5 shadow-xs space-y-3">
            <h4 className="text-[10px] font-mono tracking-widest text-stone-500 uppercase font-black flex items-center gap-1">
              <Zap className="w-3.5 h-3.5 text-amber-600" /> Our Philosophy
            </h4>
            <p className="text-[11px] leading-relaxed text-stone-500">
              We believe decisions are best made by breaking them down into small, digestible pieces: weighed priorities, direct pros and cons, and honest side-by-side reviews.
            </p>
          </div>
        </aside>

        {/* Content Workspace */}
        <section id="app-workspace" className="lg:col-span-9 order-1 lg:order-2 space-y-6">
          
          {error && (
            <div id="error-banner" className="bg-red-50 border border-red-200 rounded-2xl p-4 flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
              <div>
                <h4 className="text-xs font-mono uppercase tracking-widest font-black text-red-700">Something went wrong</h4>
                <p className="text-xs text-red-600/90 mt-1 leading-relaxed">{error}</p>
                <button 
                  onClick={() => setError(null)}
                  className="text-xs font-mono font-bold text-red-700 underline mt-2 hover:text-red-900 block cursor-pointer"
                >
                  Clear message
                </button>
              </div>
            </div>
          )}

          {!currentRecord && !isLoading ? (
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              id="empty-state-intro"
              className="space-y-6"
            >
              {/* Introduction Banner */}
              <div className="relative overflow-hidden bg-white border border-stone-200 rounded-2xl p-6 md:p-8 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-6">
                <div className="space-y-3 max-w-2xl">
                  <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-stone-100 border border-stone-200 text-stone-600 text-[10px] font-mono uppercase tracking-widest font-bold">
                    🌿 Let's simplify your decision
                  </span>
                  <h2 className="text-2xl font-bold tracking-tight text-stone-900 font-display leading-tight">
                    Which path feels right for you?
                  </h2>
                  <p className="text-xs text-stone-500 leading-relaxed max-w-xl font-medium">
                    If you're stuck at a crossroads, we can help you organize your thoughts. Share what's on your mind, list your options, and we'll break down the trade-offs, pros & cons, and opportunities together.
                  </p>
                </div>
              </div>

              {/* Input Form */}
              <DecisionForm onSubmit={handleAnalyze} isLoading={isLoading} />
            </motion.div>
          ) : isLoading ? (
            <div id="loading-workspace" className="bg-white border border-stone-200 rounded-2xl p-12 shadow-xs flex flex-col items-center justify-center text-center space-y-6 min-h-[500px]">
              <div className="relative flex items-center justify-center">
                {/* Rotating ring */}
                <div className="w-16 h-16 rounded-full border-4 border-stone-100 border-t-amber-600 animate-spin"></div>
                {/* Secondary ring */}
                <div className="w-12 h-12 rounded-full border-2 border-stone-100 border-b-stone-400 animate-spin absolute" style={{ animationDirection: 'reverse', animationDuration: '1.2s' }}></div>
              </div>
              <div className="space-y-3 max-w-sm">
                <h3 className="text-sm font-bold text-stone-900 uppercase tracking-wide">Organizing your thoughts...</h3>
                <p className="text-[10px] text-stone-400 font-mono uppercase tracking-widest font-bold">
                  Weighing options & priorities
                </p>
                <div className="pt-3 text-xs text-stone-500 italic max-w-xs mx-auto leading-relaxed border-t border-stone-100">
                  "Wrangling the pros and cons, sorting the details, and preparing a thoughtful layout for you..."
                </div>
              </div>
            </div>
          ) : (
            currentRecord && currentRecord.report && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="space-y-6"
              >
                {/* Result Header */}
                <div id="result-meta-header" className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white border border-stone-200 rounded-2xl p-6 shadow-xs relative overflow-hidden">
                  <div className="absolute top-0 left-0 w-1.5 h-full bg-amber-600"></div>
                  <div className="space-y-1 relative z-10 pl-2">
                    <div className="flex items-center gap-2">
                      <span className="text-[9px] font-mono uppercase tracking-widest text-stone-400 font-bold">
                        Your Custom Summary
                      </span>
                      <span className="w-1.5 h-1.5 rounded-full bg-amber-600 animate-pulse"></span>
                    </div>
                    <h2 className="text-base font-bold tracking-tight text-stone-900 font-display">
                      {currentRecord.report.title}
                    </h2>
                    {currentRecord.context && (
                      <p className="text-xs text-stone-500 italic line-clamp-1 mt-1 font-sans">
                        "{currentRecord.context}"
                      </p>
                    )}
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      id="back-to-input-btn"
                      onClick={handleNewDecision}
                      className="px-3 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-700 border border-stone-200 rounded-lg text-xs font-semibold transition duration-150 cursor-pointer shadow-xs"
                    >
                      Start Over
                    </button>
                    <button
                      id="re-analyze-btn"
                      onClick={() => handleAnalyze(currentRecord.title, currentRecord.context, currentRecord.options, currentRecord.criteria)}
                      className="p-1.5 bg-stone-100 hover:bg-stone-200 text-stone-600 border border-stone-200 rounded-lg transition duration-150 cursor-pointer shadow-xs"
                      title="Re-evaluate"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Main Tab Controls */}
                <div id="tabs-navigation" className="bg-stone-100/85 border border-stone-200/60 rounded-xl p-1 shadow-xs flex flex-wrap gap-1">
                  {[
                    { id: "verdict", label: "Our Advice", icon: CheckCircle },
                    { id: "matrix", label: "Priority Matrix", icon: BarChart3 },
                    { id: "comparison", label: "Side-by-Side", icon: Layers },
                    { id: "swot", label: "Strengths & Risks", icon: TrendingUp },
                    { id: "proscons", label: "Pros & Cons", icon: AlertTriangle },
                  ].map((tab) => {
                    const Icon = tab.icon;
                    const isActive = activeTab === tab.id;
                    return (
                      <button
                        key={tab.id}
                        id={`tab-btn-${tab.id}`}
                        onClick={() => setActiveTab(tab.id as any)}
                        className={`flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-semibold transition duration-150 select-none flex-1 min-w-[110px] justify-center sm:justify-start cursor-pointer ${
                          isActive 
                            ? "bg-white border border-stone-200 text-stone-900 shadow-xs font-bold" 
                            : "text-stone-500 hover:text-stone-850 border border-transparent hover:bg-stone-50"
                        }`}
                      >
                        <Icon className={`w-3.5 h-3.5 shrink-0 ${isActive ? "text-amber-600" : "text-stone-400"}`} />
                        {tab.label}
                      </button>
                    );
                  })}
                </div>

                {/* Tabs Body */}
                <div id="tabs-content-body" className="min-h-[400px]">
                  <AnimatePresence mode="wait">
                    
                    {/* VERDICT TAB */}
                    {activeTab === "verdict" && (
                      <motion.div
                        key="verdict-tab"
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        className="space-y-6"
                      >
                        <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
                          
                          {/* Recommended Advice */}
                          <div className="md:col-span-8 bg-white border border-stone-200 rounded-2xl p-6 md:p-8 shadow-xs space-y-6 flex flex-col justify-between relative">
                            <div className="space-y-4">
                              <div className="flex items-center gap-2">
                                <span className="px-2.5 py-1 rounded-md bg-amber-50 text-amber-800 border border-amber-200 text-[10px] font-mono font-bold uppercase tracking-wider flex items-center gap-1">
                                  <Award className="w-3.5 h-3.5" /> A Thoughtful Recommendation
                                </span>
                              </div>
                              
                              <h3 className="text-lg font-bold text-stone-950 font-display">
                                {currentRecord.report.verdict.winner}
                              </h3>
                              
                              <p className="text-xs md:text-sm text-stone-600 leading-relaxed font-sans font-medium">
                                {currentRecord.report.verdict.tiebreakerReasoning}
                              </p>
                            </div>

                            {/* Summary Box */}
                            <div className="pt-4 border-t border-stone-100">
                              <span className="text-[10px] uppercase font-mono tracking-wider text-stone-400 font-bold block mb-1">
                                Quick Summary
                              </span>
                              <span className="text-xs text-stone-500 block leading-relaxed font-medium">
                                {currentRecord.report.summary}
                              </span>
                            </div>
                          </div>

                          {/* Confidence Dial */}
                          <div className="md:col-span-4 bg-white border border-stone-200 rounded-2xl p-6 md:p-8 shadow-xs flex flex-col justify-between space-y-6">
                            <div>
                              <span className="text-[10px] font-mono uppercase tracking-wider text-stone-400 font-bold block mb-1">
                                Confidence
                              </span>
                              <h4 className="text-xs font-bold font-display text-stone-700">
                                Balance Score
                              </h4>
                            </div>

                            {/* Circle visualizer */}
                            <div className="relative w-32 h-32 mx-auto flex items-center justify-center">
                              <svg className="w-full h-full transform -rotate-90">
                                <circle
                                  cx="64"
                                  cy="64"
                                  r="50"
                                  className="stroke-stone-100"
                                  strokeWidth="6"
                                  fill="transparent"
                                />
                                <circle
                                  cx="64"
                                  cy="64"
                                  r="50"
                                  className="stroke-amber-600"
                                  strokeWidth="6"
                                  fill="transparent"
                                  strokeDasharray={2 * Math.PI * 50}
                                  strokeDashoffset={2 * Math.PI * 50 * (1 - currentRecord.report.verdict.confidenceScore / 100)}
                                  strokeLinecap="round"
                                />
                              </svg>
                              <div className="absolute text-center">
                                <span className="text-2xl font-bold font-mono text-stone-900">
                                  {currentRecord.report.verdict.confidenceScore}%
                                </span>
                                <span className="text-[9px] font-mono uppercase text-stone-400 block font-bold">
                                  Confidence
                                </span>
                              </div>
                            </div>

                            <p className="text-[10px] text-stone-400 leading-relaxed text-center font-sans font-medium">
                              Calculated by balancing the pros, cons, and priorities you care about most.
                            </p>
                          </div>
                        </div>

                        {/* Actionable Next Steps */}
                        <div className="bg-white border border-stone-200 rounded-2xl p-6 shadow-xs space-y-4">
                          <h4 className="text-xs font-mono uppercase tracking-wider text-stone-500 font-bold flex items-center gap-1.5">
                            <Zap className="w-4 h-4 text-amber-600" /> Recommended Next Steps
                          </h4>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {currentRecord.report.verdict.nextSteps.map((step, idx) => (
                              <div key={idx} className="flex gap-3 bg-stone-50 hover:bg-stone-100/50 p-4 rounded-xl border border-stone-200 transition duration-150">
                                <span className="w-6 h-6 rounded-lg bg-stone-900 text-white flex items-center justify-center text-xs font-mono font-bold shrink-0">
                                  0{idx + 1}
                                </span>
                                <p className="text-xs text-stone-700 leading-relaxed font-medium">
                                  {step}
                                </p>
                              </div>
                            ))}
                          </div>
                        </div>
                      </motion.div>
                    )}

                    {/* DECISION MATRIX */}
                    {activeTab === "matrix" && (
                      <motion.div
                        key="matrix-tab"
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        className="space-y-6"
                      >
                        {/* Intro and Rank List */}
                        <div className="bg-white border border-stone-200 rounded-2xl p-6 shadow-xs space-y-4">
                          <div>
                            <h3 className="text-sm font-bold text-stone-950 font-display">
                              Weighted Priority Scoring
                            </h3>
                            <p className="text-xs text-stone-500 mt-0.5 leading-relaxed font-medium">
                              Each key factor is assigned a weight based on how much it impacts your satisfaction. Below is the total score for each choice based on those priorities.
                            </p>
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                            {matrixResults.map((result, idx) => {
                              const isHighest = idx === 0;
                              const percentageOfScale = (result.totalScore / 10) * 100;
                              return (
                                <div key={result.option} className={`p-4 rounded-xl border flex flex-col justify-between relative transition duration-150 ${
                                  isHighest 
                                    ? "bg-white border-amber-600/30 shadow-xs ring-1 ring-amber-600/10 text-stone-900" 
                                    : "bg-stone-50 border-stone-200 text-stone-600"
                                }`}>
                                  {isHighest && (
                                    <div className="absolute top-0 right-0 px-2.5 py-0.5 bg-amber-600 text-white font-mono font-bold text-[8px] uppercase tracking-wider rounded-bl-lg">
                                      Suggested choice
                                    </div>
                                  )}
                                  <div className="flex justify-between items-start mb-3">
                                    <div className="space-y-1">
                                      <span className={`text-[8px] font-mono font-black uppercase tracking-wider ${isHighest ? "text-amber-700" : "text-stone-400"}`}>
                                        RANK #{idx + 1}
                                      </span>
                                      <h4 className="text-xs font-bold font-display leading-tight">{result.option}</h4>
                                    </div>
                                    <div className="text-right">
                                      <span className="text-base font-mono font-bold text-stone-900">{result.totalScore}</span>
                                      <span className="text-[10px] text-stone-400"> / 10</span>
                                    </div>
                                  </div>

                                  <div className="w-full bg-stone-200/60 rounded-full h-1.5 overflow-hidden">
                                    <div 
                                      className={`h-full rounded-full transition-all duration-1000 ${isHighest ? "bg-amber-600" : "bg-stone-400"}`} 
                                      style={{ width: `${percentageOfScale}%` }}
                                    ></div>
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        </div>

                        {/* Factor breakdown table */}
                        <div className="bg-white border border-stone-200 rounded-2xl overflow-hidden shadow-xs">
                          <div className="p-4 border-b border-stone-100 bg-stone-50/50">
                            <h4 className="text-[10px] font-mono uppercase tracking-wider text-stone-500 font-bold">
                              Detailed Breakdown
                            </h4>
                          </div>

                          <div className="overflow-x-auto">
                            <table className="w-full text-left border-collapse">
                              <thead>
                                <tr className="border-b border-stone-200 bg-stone-50/40 text-[9px] font-mono uppercase tracking-wider text-stone-400">
                                  <th className="py-3 px-5 font-bold">Factor Name</th>
                                  <th className="py-3 px-5 text-center font-bold">Priority Weight</th>
                                  {currentRecord.report.options.map((opt) => (
                                    <th key={opt} className="py-3 px-5 text-right font-bold">{opt} Score</th>
                                  ))}
                                </tr>
                              </thead>
                              <tbody className="divide-y divide-stone-100 text-xs text-stone-700">
                                {currentRecord.report.decisionMatrix.factors.map((factor) => (
                                  <tr key={factor.name} className="hover:bg-stone-50/50 transition">
                                    <td className="py-3.5 px-5 font-semibold text-stone-900 font-display">
                                      {factor.name}
                                    </td>
                                    <td className="py-3.5 px-5 text-center font-mono font-bold text-amber-700">
                                      {Math.round(factor.weight * 100)}%
                                    </td>
                                    {currentRecord.report.options.map((opt) => {
                                      const scoreObj = factor.scores?.find(s => s?.option?.toLowerCase().trim() === opt?.toLowerCase().trim());
                                      const scoreVal = scoreObj ? scoreObj.score : 0;
                                      return (
                                        <td key={opt} className="py-3.5 px-5 text-right font-medium">
                                          <div className="inline-flex items-center gap-1.5">
                                            <span className="font-mono font-bold text-stone-900">{scoreVal}</span>
                                            <span className="text-[9px] text-stone-400">/10</span>
                                            <span className="text-[10px] text-stone-500 font-mono bg-stone-50 border border-stone-200 px-1.5 py-0.5 rounded-md">
                                              ({Math.round(scoreVal * (factor.weight || 0) * 10) / 10})
                                            </span>
                                          </div>
                                        </td>
                                      );
                                    })}
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                        </div>
                      </motion.div>
                    )}

                    {/* COMPARISON TABLE */}
                    {activeTab === "comparison" && (
                      <motion.div
                        key="comparison-tab"
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        className="bg-white border border-stone-200 rounded-2xl overflow-hidden shadow-xs"
                      >
                        <div className="p-6 border-b border-stone-200 bg-stone-50/50">
                          <h3 className="text-sm font-bold text-stone-950 font-display">
                            Side-by-Side Comparison
                          </h3>
                          <p className="text-xs text-stone-500 mt-0.5 leading-relaxed font-medium">
                            An easy-to-read score card for each priority factor, with brief comparative notes.
                          </p>
                        </div>

                        <div className="overflow-x-auto">
                          <table className="w-full text-left border-collapse">
                            <thead>
                              <tr className="border-b border-stone-200 bg-stone-50/40 text-[9px] font-mono uppercase tracking-wider text-stone-400">
                                <th className="py-3 px-5 font-bold">Priority Factor</th>
                                {currentRecord.report.comparisonTable.headers.slice(1).map((header, idx) => (
                                  <th key={idx} className="py-3 px-5 text-center font-bold">{header}</th>
                                ))}
                                <th className="py-3 px-5 max-w-sm font-bold">Notes & Trade-offs</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-stone-100 text-xs text-stone-700">
                              {currentRecord.report.comparisonTable.rows.map((row, idx) => (
                                <tr key={idx} className="hover:bg-stone-50/50 transition">
                                  <td className="py-4 px-5 font-bold text-stone-900 font-display">
                                    {row.criteria}
                                  </td>
                                  {currentRecord.report.options.map((opt) => {
                                    const optScore = row.scores?.find(s => s?.option?.toLowerCase().trim() === opt?.toLowerCase().trim())?.score || 0;
                                    let scoreColor = "bg-stone-50 border border-stone-200 text-stone-600";
                                    if (optScore >= 8) scoreColor = "bg-teal-50 border-teal-200 text-teal-800";
                                    else if (optScore <= 4) scoreColor = "bg-orange-50 border-orange-200 text-orange-800";

                                    return (
                                      <td key={opt} className="py-4 px-5 text-center">
                                        <span className={`inline-flex items-center justify-center w-10 h-7 rounded-lg font-mono font-bold ${scoreColor}`}>
                                          {optScore}
                                        </span>
                                      </td>
                                    );
                                  })}
                                  <td className="py-4 px-5 max-w-sm text-stone-600 leading-relaxed font-sans font-medium">
                                    {row.explanation}
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </motion.div>
                    )}

                    {/* SWOT DIAGRAMS */}
                    {activeTab === "swot" && (
                      <motion.div
                        key="swot-tab"
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        className="space-y-6"
                      >
                        {currentRecord.report.swotAnalysis.map((swot, sIdx) => (
                          <div key={sIdx} className="bg-white border border-stone-200 rounded-2xl p-6 md:p-8 shadow-xs space-y-5">
                            <div className="flex items-center gap-2 pb-2.5 border-b border-stone-100">
                              <span className="w-5 h-5 flex items-center justify-center rounded-md bg-stone-900 text-white text-[10px] font-mono font-bold">
                                0{sIdx + 1}
                              </span>
                              <h3 className="text-xs font-black text-stone-900 font-display uppercase tracking-wider">
                                Strengths & Risks: <span className="text-amber-700 font-bold font-sans tracking-normal normal-case">{swot.option}</span>
                              </h3>
                            </div>

                            {/* Grid SWOT */}
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                              
                              {/* Strengths */}
                              <div className="p-4.5 rounded-xl bg-teal-50/50 border border-teal-100 flex flex-col gap-2.5">
                                <span className="inline-flex items-center gap-1.5 text-[10px] font-mono font-bold text-teal-800 uppercase tracking-wider">
                                  <span className="w-1.5 h-1.5 rounded-full bg-teal-500"></span>
                                  Strengths
                                </span>
                                <ul className="space-y-1.5 text-xs text-stone-700 font-sans font-medium">
                                  {swot.strengths.map((str, i) => (
                                    <li key={i} className="flex items-start gap-1.5 leading-relaxed">
                                      <span className="text-teal-600 select-none">•</span>
                                      {str}
                                    </li>
                                  ))}
                                </ul>
                              </div>

                              {/* Weaknesses */}
                              <div className="p-4.5 rounded-xl bg-orange-50/50 border border-orange-100 flex flex-col gap-2.5">
                                <span className="inline-flex items-center gap-1.5 text-[10px] font-mono font-bold text-orange-800 uppercase tracking-wider">
                                  <span className="w-1.5 h-1.5 rounded-full bg-orange-500"></span>
                                  Weaknesses
                                </span>
                                <ul className="space-y-1.5 text-xs text-stone-700 font-sans font-medium">
                                  {swot.weaknesses.map((wk, i) => (
                                    <li key={i} className="flex items-start gap-1.5 leading-relaxed">
                                      <span className="text-orange-600 select-none">•</span>
                                      {wk}
                                    </li>
                                  ))}
                                </ul>
                              </div>

                              {/* Opportunities */}
                              <div className="p-4.5 rounded-xl bg-sky-50/50 border border-sky-100 flex flex-col gap-2.5">
                                <span className="inline-flex items-center gap-1.5 text-[10px] font-mono font-bold text-sky-800 uppercase tracking-wider">
                                  <span className="w-1.5 h-1.5 rounded-full bg-sky-500"></span>
                                  Opportunities
                                </span>
                                <ul className="space-y-1.5 text-xs text-stone-700 font-sans font-medium">
                                  {swot.opportunities.map((op, i) => (
                                    <li key={i} className="flex items-start gap-1.5 leading-relaxed">
                                      <span className="text-sky-600 select-none">•</span>
                                      {op}
                                    </li>
                                  ))}
                                </ul>
                              </div>

                              {/* Threats */}
                              <div className="p-4.5 rounded-xl bg-amber-50/50 border border-amber-100 flex flex-col gap-2.5">
                                <span className="inline-flex items-center gap-1.5 text-[10px] font-mono font-bold text-amber-800 uppercase tracking-wider">
                                  <span className="w-1.5 h-1.5 rounded-full bg-amber-500"></span>
                                  Threats / Risks
                                </span>
                                <ul className="space-y-1.5 text-xs text-stone-700 font-sans font-medium">
                                  {swot.threats.map((th, i) => (
                                    <li key={i} className="flex items-start gap-1.5 leading-relaxed">
                                      <span className="text-amber-600 select-none">•</span>
                                      {th}
                                    </li>
                                  ))}
                                </ul>
                              </div>

                            </div>
                          </div>
                        ))}
                      </motion.div>
                    )}

                    {/* PROS & CONS */}
                    {activeTab === "proscons" && (
                      <motion.div
                        key="proscons-tab"
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        className="space-y-6"
                      >
                        {currentRecord.report.prosCons.map((pc, idx) => (
                          <div key={idx} className="bg-white border border-stone-200 rounded-2xl p-6 md:p-8 shadow-xs space-y-5">
                            <div className="pb-3 border-b border-stone-100">
                              <span className="text-[9px] font-mono uppercase tracking-wider text-stone-400 block mb-1 font-bold">
                                Option 0{idx + 1}
                              </span>
                              <h3 className="text-sm font-bold text-stone-900 font-display">
                                {pc.option}
                              </h3>
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                              {/* Pros Column */}
                              <div className="space-y-3">
                                <div className="flex items-center gap-1.5 pb-2 border-b border-stone-100">
                                  <span className="w-1.5 h-1.5 rounded-full bg-teal-500"></span>
                                  <h4 className="text-[10px] font-mono font-bold text-teal-800 uppercase tracking-wider">
                                    Pros
                                  </h4>
                                </div>

                                <div className="space-y-2.5">
                                  {pc.pros.map((pro, i) => (
                                    <div key={i} className="bg-teal-50/10 p-4 rounded-xl border border-teal-100/50 flex flex-col gap-1 hover:border-teal-200 transition">
                                      <div className="flex items-start justify-between gap-2">
                                        <span className="font-bold text-stone-900 text-xs font-display">
                                          {pro.text}
                                        </span>
                                        <span className="px-1.5 py-0.5 rounded bg-teal-100 text-teal-900 border border-teal-200 text-[9px] font-mono font-bold whitespace-nowrap">
                                          Impact: +{pro.score}/5
                                        </span>
                                      </div>
                                      <p className="text-[11px] text-stone-500 leading-relaxed font-sans font-medium">
                                        {pro.description}
                                      </p>
                                    </div>
                                  ))}
                                </div>
                              </div>

                              {/* Cons Column */}
                              <div className="space-y-3">
                                <div className="flex items-center gap-1.5 pb-2 border-b border-stone-100">
                                  <span className="w-1.5 h-1.5 rounded-full bg-orange-500"></span>
                                  <h4 className="text-[10px] font-mono font-bold text-orange-800 uppercase tracking-wider">
                                    Cons
                                  </h4>
                                </div>

                                <div className="space-y-2.5">
                                  {pc.cons.map((con, i) => (
                                    <div key={i} className="bg-orange-50/10 p-4 rounded-xl border border-orange-100/50 flex flex-col gap-1 hover:border-orange-200 transition">
                                      <div className="flex items-start justify-between gap-2">
                                        <span className="font-bold text-stone-900 text-xs font-display">
                                          {con.text}
                                        </span>
                                        <span className="px-1.5 py-0.5 rounded bg-orange-100 text-orange-900 border border-orange-200 text-[9px] font-mono font-bold whitespace-nowrap">
                                          Gravity: -{con.score}/5
                                        </span>
                                      </div>
                                      <p className="text-[11px] text-stone-500 leading-relaxed font-sans font-medium">
                                        {con.description}
                                      </p>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            </div>
                          </div>
                        ))}
                      </motion.div>
                    )}

                  </AnimatePresence>
                </div>

              </motion.div>
            )
          )}

        </section>

      </main>

      {/* Footer */}
      <footer id="app-footer" className="mt-auto border-t border-stone-200 bg-white/60 py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-4 text-[10px] text-stone-400 font-mono tracking-wide uppercase">
          <p>© 2026 The Tiebreaker. A gentle guide designed with a human touch.</p>
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-teal-500"></span> Advisor online
            </span>
            <span className="text-stone-200">|</span>
            <span className="hover:text-stone-600 cursor-pointer" onClick={handleNewDecision}>
              Reset Workspace
            </span>
          </div>
        </div>
      </footer>
    </div>
  );
}
