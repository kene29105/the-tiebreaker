import React, { useState } from "react";
import { HelpCircle, Plus, Trash2, Check } from "lucide-react";

interface DecisionFormProps {
  onSubmit: (title: string, context: string, options: string[], criteria: string[]) => void;
  isLoading: boolean;
}

const EXAMPLES = [
  {
    title: "Tesla Model Y vs. Honda CR-V Hybrid",
    context: "I drive 40 miles daily for my commute, have garage access for home charging, and live in a snowy area. Budget is around $45k.",
    options: ["Tesla Model Y", "Honda CR-V Hybrid"],
    criteria: ["Overall Cost", "Winter Safety", "Commuting Comfort", "Eco-friendliness"]
  },
  {
    title: "Rust vs. Python for High-Performance Service",
    context: "I am building a web analytics engine that needs to handle high concurrency, but I also need to launch a working prototype within 3 months.",
    options: ["Rust", "Python"],
    criteria: ["Development Speed", "Execution Speed", "Developer Joy", "Concurrency"]
  },
  {
    title: "Relocate to Seattle or stay in Chicago?",
    context: "My partner has a remote job, and I have a job offer in Seattle with a 15% salary increase. We love outdoors but rent is 30% higher in Seattle.",
    options: ["Relocate to Seattle", "Remain in Chicago"],
    criteria: ["Career Growth", "Cost of Living", "Access to Nature", "Proximity to Family"]
  }
];

export default function DecisionForm({ onSubmit, isLoading }: DecisionFormProps) {
  const [title, setTitle] = useState("");
  const [context, setContext] = useState("");
  const [options, setOptions] = useState<string[]>(["Option A", "Option B"]);
  const [criteria, setCriteria] = useState<string[]>([]);
  const [newOption, setNewOption] = useState("");
  const [newCriterion, setNewCriterion] = useState("");

  const handleAddOption = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = newOption.trim();
    if (trimmed && !options.includes(trimmed)) {
      setOptions([...options, trimmed]);
      setNewOption("");
    }
  };

  const handleRemoveOption = (index: number) => {
    if (options.length > 2) {
      setOptions(options.filter((_, i) => i !== index));
    }
  };

  const handleAddCriterion = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = newCriterion.trim();
    if (trimmed && !criteria.includes(trimmed)) {
      setCriteria([...criteria, trimmed]);
      setNewCriterion("");
    }
  };

  const handleRemoveCriterion = (index: number) => {
    setCriteria(criteria.filter((_, i) => i !== index));
  };

  const handleLoadExample = (example: typeof EXAMPLES[0]) => {
    setTitle(example.title);
    setContext(example.context);
    setOptions(example.options);
    setCriteria(example.criteria);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;
    onSubmit(
      title.trim(),
      context.trim(),
      options.map(o => o.trim()).filter(Boolean),
      criteria.map(c => c.trim()).filter(Boolean)
    );
  };

  return (
    <div id="decision-form-container" className="space-y-6">
      {/* Examples Selection */}
      <div id="quick-examples-section" className="space-y-2">
        <span className="text-[11px] font-mono uppercase tracking-widest text-stone-500 font-bold block">
          🌱 Or load an example scenario to see how it works
        </span>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {EXAMPLES.map((ex, idx) => (
            <button
              key={idx}
              id={`example-btn-${idx}`}
              type="button"
              onClick={() => handleLoadExample(ex)}
              className="text-left p-4 bg-white hover:bg-[#fbfbfa] border border-stone-200 hover:border-amber-600/40 rounded-xl transition duration-150 group text-xs flex flex-col justify-between h-full cursor-pointer shadow-xs"
            >
              <span className="font-semibold text-stone-800 line-clamp-2 mb-3 group-hover:text-amber-700 font-display leading-relaxed">
                {ex.title}
              </span>
              <div className="flex items-center justify-between w-full border-t border-stone-100 pt-2 text-[10px] font-mono text-stone-400">
                <span>Scenario {idx + 1}</span>
                <span className="text-amber-600 font-bold group-hover:underline">Use preset →</span>
              </div>
            </button>
          ))}
        </div>
      </div>

      <form 
        id="main-decision-form" 
        onSubmit={handleSubmit} 
        className="bg-white border border-stone-200 rounded-2xl p-6 md:p-8 shadow-sm space-y-6"
      >
        {/* Title */}
        <div className="space-y-1.5">
          <label htmlFor="decision-title" className="block text-xs font-mono uppercase tracking-wider text-stone-500 font-bold">
            What is the decision you are trying to make? <span className="text-amber-600">*</span>
          </label>
          <input
            id="decision-title"
            type="text"
            required
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="e.g., Should I rent a house in the suburbs or buy a small flat in the city?"
            className="w-full px-4 py-3 bg-stone-50/50 border border-stone-200 rounded-xl text-stone-800 placeholder-stone-400 focus:outline-none focus:ring-2 focus:ring-amber-600/10 focus:border-amber-600 transition-all text-sm font-medium leading-relaxed"
          />
        </div>

        {/* Context */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between">
            <label htmlFor="decision-context" className="block text-xs font-mono uppercase tracking-wider text-stone-500 font-bold">
              Tell us a little more about your situation <span className="text-[10px] font-normal text-stone-400">(Optional but helpful)</span>
            </label>
            <div className="group relative flex items-center text-stone-400 hover:text-stone-600 cursor-pointer">
              <HelpCircle className="w-4 h-4" />
              <span className="absolute bottom-full right-0 mb-2 w-72 p-3 bg-stone-900 text-stone-100 text-[11px] rounded-lg opacity-0 pointer-events-none group-hover:opacity-100 transition-opacity duration-150 z-10 leading-relaxed shadow-lg">
                Adding details like your budget, timeline, values, or any specific trade-offs helps the advisor give much more personalized guidance.
              </span>
            </div>
          </div>
          <textarea
            id="decision-context"
            rows={3}
            value={context}
            onChange={(e) => setContext(e.target.value)}
            placeholder="e.g., 'I want a short commute to work, but I also value quiet weekends. My budget is around $2,500/month, and I'd like to make this move within the next 3 months.'"
            className="w-full px-4 py-3 bg-stone-50/50 border border-stone-200 rounded-xl text-stone-800 placeholder-stone-400 focus:outline-none focus:ring-2 focus:ring-amber-600/10 focus:border-amber-600 transition-all text-sm resize-none leading-relaxed"
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
          {/* Options Section */}
          <div className="space-y-3">
            <label className="block text-xs font-mono uppercase tracking-wider text-stone-500 font-bold">
              What choices are you weighing? <span className="text-[10px] font-normal text-stone-400">(Enter at least 2)</span>
            </label>
            
            <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1">
              {options.map((option, index) => (
                <div key={index} className="flex items-center gap-2 bg-stone-50 border border-stone-200 px-3 py-2 rounded-xl group hover:border-stone-300 transition duration-150">
                  <span className="w-5 h-5 flex items-center justify-center rounded-md bg-amber-100 text-amber-800 border border-amber-200 text-[10px] font-mono font-bold">
                    0{index + 1}
                  </span>
                  <span className="text-xs font-medium text-stone-700 flex-1">{option}</span>
                  {options.length > 2 && (
                    <button
                      id={`remove-option-${index}`}
                      type="button"
                      onClick={() => handleRemoveOption(index)}
                      className="text-stone-400 hover:text-red-600 transition duration-150 p-1 cursor-pointer"
                      title="Remove option"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              ))}
            </div>

            {/* Add Option Input */}
            <div className="flex gap-2">
              <input
                id="new-option-input"
                type="text"
                value={newOption}
                onChange={(e) => setNewOption(e.target.value)}
                placeholder="Add another option (e.g., Buy flat)"
                className="flex-1 px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs font-medium focus:outline-none focus:border-amber-600/60 text-stone-800 placeholder-stone-400"
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    e.preventDefault();
                    const trimmed = newOption.trim();
                    if (trimmed && !options.includes(trimmed)) {
                      setOptions([...options, trimmed]);
                      setNewOption("");
                    }
                  }
                }}
              />
              <button
                id="add-option-btn"
                type="button"
                onClick={(e) => handleAddOption(e)}
                className="px-3 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-xl transition duration-150 flex items-center justify-center border border-stone-200 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Criteria Section */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="block text-xs font-mono uppercase tracking-wider text-stone-500 font-bold">
                Things that matter to you <span className="text-[10px] font-normal text-stone-400">(Optional)</span>
              </label>
            </div>
            
            <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1">
              {criteria.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-4 text-center border border-dashed border-stone-200 rounded-xl bg-stone-50/40">
                  <span className="text-xs text-stone-500 font-medium">Automatic priorities enabled</span>
                  <p className="text-[10px] text-stone-400 max-w-[240px] mt-1 leading-relaxed">
                    Leave this empty, and the guide will automatically determine the best factors (like cost, time, and comfort) based on your scenario.
                  </p>
                </div>
              ) : (
                criteria.map((criterion, index) => (
                  <div key={index} className="flex items-center gap-2 bg-stone-50 border border-stone-200 px-3 py-2 rounded-xl group hover:border-stone-300 transition duration-150">
                    <span className="text-xs text-stone-700 flex-1 font-medium">✓ {criterion}</span>
                    <button
                      id={`remove-criterion-${index}`}
                      type="button"
                      onClick={() => handleRemoveCriterion(index)}
                      className="text-stone-400 hover:text-red-600 transition duration-150 p-1 cursor-pointer"
                      title="Remove factor"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))
              )}
            </div>

            {/* Add Criterion Input */}
            <div className="flex gap-2">
              <input
                id="new-criterion-input"
                type="text"
                value={newCriterion}
                onChange={(e) => setNewCriterion(e.target.value)}
                placeholder="Add priority (e.g., Low Maintenance)"
                className="flex-1 px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs font-medium focus:outline-none focus:border-amber-600/60 text-stone-800 placeholder-stone-400"
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    e.preventDefault();
                    const trimmed = newCriterion.trim();
                    if (trimmed && !criteria.includes(trimmed)) {
                      setCriteria([...criteria, trimmed]);
                      setNewCriterion("");
                    }
                  }
                }}
              />
              <button
                id="add-criterion-btn"
                type="button"
                onClick={(e) => handleAddCriterion(e)}
                className="px-3 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-xl transition duration-150 flex items-center justify-center border border-stone-200 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Submit Button */}
        <div className="pt-4 flex items-center justify-end">
          <button
            id="submit-decision-btn"
            type="submit"
            disabled={isLoading || !title.trim()}
            className="px-5 py-3 bg-stone-900 hover:bg-stone-800 text-white rounded-xl transition duration-150 font-semibold text-xs flex items-center gap-2 shadow-xs disabled:bg-stone-100 disabled:text-stone-400 disabled:shadow-none disabled:cursor-not-allowed cursor-pointer"
          >
            {isLoading ? (
              <>
                <svg className="animate-spin h-3.5 w-3.5 text-stone-400" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                </svg>
                Organizing thoughts...
              </>
            ) : (
              <>
                Give me clarity
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
}
