export interface ProConItem {
  text: string;
  score: number; // 1 to 5 gravity
  description: string;
}

export interface OptionProsCons {
  option: string;
  pros: ProConItem[];
  cons: ProConItem[];
}

export interface OptionScore {
  option: string;
  score: number; // 1 to 10
}

export interface ComparisonRow {
  criteria: string;
  scores: OptionScore[];
  explanation: string;
}

export interface ComparisonTable {
  headers: string[];
  rows: ComparisonRow[];
}

export interface OptionSWOT {
  option: string;
  strengths: string[];
  weaknesses: string[];
  opportunities: string[];
  threats: string[];
}

export interface MatrixFactor {
  name: string;
  weight: number; // Float, e.g. 0.25
  scores: OptionScore[];
}

export interface DecisionMatrix {
  factors: MatrixFactor[];
}

export interface Verdict {
  winner: string;
  confidenceScore: number; // 0 to 100
  tiebreakerReasoning: string;
  nextSteps: string[];
}

export interface DecisionReport {
  title: string;
  summary: string;
  options: string[];
  prosCons: OptionProsCons[];
  comparisonTable: ComparisonTable;
  swotAnalysis: OptionSWOT[];
  decisionMatrix: DecisionMatrix;
  verdict: Verdict;
}

export interface DecisionRecord {
  id: string;
  title: string;
  context: string;
  options: string[];
  criteria: string[];
  createdAt: string;
  report?: DecisionReport;
}
